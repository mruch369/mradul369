
package com.example.oicapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.oicapp.databinding.ActivityMainBinding
import com.google.firebase.database.*

data class Business(val name: String = "", val address: String = "", val category: String = "", val rating: String = "")

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var database: DatabaseReference
    private lateinit var businessList: MutableList<Business>
    private lateinit var adapter: BusinessAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        businessList = mutableListOf()
        database = FirebaseDatabase.getInstance().getReference("businesses")

        setupRecyclerView()
        loadBusinesses()
    }

    private fun setupRecyclerView() {
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = BusinessAdapter(businessList)
        binding.recyclerView.adapter = adapter
    }

    private fun loadBusinesses() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                businessList.clear()
                for (data in snapshot.children) {
                    val business = data.getValue(Business::class.java)
                    business?.let { businessList.add(it) }
                }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {}
        })
    }
}
